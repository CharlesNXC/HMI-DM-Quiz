import sys
import json
import random
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QLabel, QPushButton,
    QRadioButton, QButtonGroup, QMessageBox, QComboBox, QDialog,
    QDialogButtonBox, QGridLayout
)
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import Qt

class QuizApp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Quizzzzz")
        self.setGeometry(100, 100, 700, 500)

        self.main_layout = QVBoxLayout()
        self.setLayout(self.main_layout)

        self.center_layout = QVBoxLayout()
        self.center_layout.setSpacing(20)
        self.center_layout.setAlignment(Qt.AlignCenter)

        self.main_layout.addStretch()
        self.main_layout.addLayout(self.center_layout)
        self.main_layout.addStretch()

        self.load_questions()
        self.init_intro()

        self.setStyleSheet("""
            QWidget {
                background-color: #e6f2ff;
            }
            QLabel {
                font-size: 18px;
                color: #333;
            }
            QPushButton, QComboBox {
                font-size: 16px;
                padding: 8px 16px;
                border: 1px solid #ccc;
                border-radius: 6px;
                background-color: #ffffff;
            }
            QPushButton:hover {
                background-color: #e0f7fa;
            }
        """)

    def load_questions(self):
        with open("questions_shuffled.json", "r", encoding="utf-8") as f:
            self.all_questions = json.load(f)

    def init_intro(self):
        label = QLabel("Welcome to the IQ Quiz!")
        label.setStyleSheet("font-weight: bold;")
        self.center_layout.addWidget(label)

        self.pic1 = QLabel()
        self.pic1.setPixmap(QPixmap("welcome.jpg").scaledToWidth(300)) 
        self.pic1.setAlignment(Qt.AlignCenter)
        self.center_layout.addWidget(self.pic1)

        self.center_layout.addWidget(QLabel("Choose a theme:"))
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(self.all_questions.keys())
        self.center_layout.addWidget(self.theme_combo)

        self.center_layout.addWidget(QLabel("Choose difficulty:"))
        self.diff_combo = QComboBox()
        self.diff_combo.addItems(["easy", "medium", "hard"])
        self.center_layout.addWidget(self.diff_combo)

        self.center_layout.addWidget(QLabel("Choose mode:"))
        self.mode_combo = QComboBox()
        self.mode_combo.addItems(["Solo 👤", "PvP ⚔️", "Sudden Death 💀"])
        self.center_layout.addWidget(self.mode_combo)

        start_btn = QPushButton("👉 Start Quiz 👈")
        start_btn.clicked.connect(self.start_quiz)
        self.center_layout.addWidget(start_btn)

    def show_info_popup(self):
        if "Sudden Death" in self.mode:
            msg = ("☠️ Sudden Death Mode\nYou have 3 lives to answer questions from all modes.\nAnswer wrong 3 times and it's OVER.\nSurvive as long as possible!")
        elif "PvP" in self.mode:
            msg = ("⚔️ PvP Mode\nEach player answers the same questions in turn.\nThe best score wins!")
        else:
            msg = ("👤 Solo Mode\nAnswer 10 questions.\nTry to get the best score possible!")

        QMessageBox.information(self, "Before we start", msg)

    def start_quiz(self):
        self.mode = self.mode_combo.currentText()
        theme = self.theme_combo.currentText()
        difficulty = self.diff_combo.currentText()
        
        if "Sudden Death" in self.mode:
            self.lives = 3
            self.questions = []
            for theme in self.all_questions:
                self.questions.extend(self.all_questions[theme])
            random.shuffle(self.questions)
        else:
            questions = [q for q in self.all_questions[theme] if q["difficulty"] == difficulty]
            random.shuffle(questions)
            self.questions = questions[:10]

        self.score1 = 0
        self.score2 = 0
        self.q_index = 0
        self.current_player = 1

        self.answer_summary = []

        self.clear_layout()
        self.show_info_popup()
        self.show_question()

    def clear_layout(self):
        while self.center_layout.count():
            child = self.center_layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

    def show_question(self):
        if self.q_index >= len(self.questions):
            self.show_score()
            return
        
        if "Sudden Death" in self.mode:
            if self.lives == 3 :
                life_label = QLabel(f"Lives remaining: ❤️❤️❤️")
            elif self.lives == 2 :
                life_label = QLabel(f"Lives remaining: ❤️❤️")
            elif self.lives == 1 :
                life_label = QLabel(f"Lives remaining: ❤️")

            life_label.setAlignment(Qt.AlignCenter)
            self.center_layout.addWidget(life_label)

        q = self.questions[self.q_index]
        self.center_layout.addWidget(QLabel(f"🔶 Question {self.q_index + 1}: {q['question']}"))

        self.player1_name = "Player 1"
        self.player2_name = "Player 2"

        if "PvP" in self.mode:
            name = self.player1_name if self.current_player == 1 else self.player2_name
            self.center_layout.addWidget(QLabel(f"🎮 {name}'s turn"))
        else :
            name = ""

        self.options_group = QButtonGroup(self)
        for opt in q["options"]:
            btn = QRadioButton(opt)
            self.center_layout.addWidget(btn)
            self.options_group.addButton(btn)

        next_btn = QPushButton("Next ✅")
        next_btn.clicked.connect(self.check_answer)
        self.center_layout.addWidget(next_btn)

    def check_answer(self):
        selected = self.options_group.checkedButton()
        user_answer = selected.text() if selected else "No answer"
        current_question = self.questions[self.q_index]
        correct_answer = current_question["answer"]
        question_text = current_question["question"]

        player_name = f"Player {self.current_player}" if 'PvP' in self.mode else "You"

        self.answer_summary.append({
            "question": f"{question_text} ({player_name})",
            "your_answer": user_answer,
            "correct_answer": correct_answer,
            "is_correct": user_answer == correct_answer
        })

        if "Sudden Death" in self.mode:
            if user_answer != correct_answer:
                self.lives -= 1
                if self.lives <= 0:
                    self.clear_layout()
                    self.show_sudden_death_score()
                    return
            else:
                self.score1 += 1

            self.q_index += 1
            self.clear_layout()
            self.show_question()
            return

        if user_answer == correct_answer:
            if "PvP" in self.mode:
                if self.current_player == 1:
                    self.score1 += 1
                else:
                    self.score2 += 1
            else:
                self.score1 += 1 

        if "PvP" in self.mode:
            if self.current_player == 1:
                self.current_player = 2
            else:
                self.current_player = 1
                self.q_index += 1
        else:
            self.q_index += 1  

        self.clear_layout()
        self.show_question()
    
    def get_score_image(self, score):
        if score <= 2:
            return "bad.png"
        elif 3 <= score <= 5:
            return "meh.jpg"
        elif 6<= score <= 7:
            return "good.jpg"
        elif 7 < score <= 9:
            return "fire.jpg"
        else:
            return "god.jpg"

    def show_score(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Quiz Finished")
        dialog.resize(600, 600)
        layout = QVBoxLayout()

        comment = ""

        if "PvP" not in self.mode:
            if self.score1 <= 2:
                comment = "💀 Back to school"
            elif 3 <= self.score1 <= 5:
                comment = "🫤 Could be worse"
            elif 6<= self.score1 <= 7:
                comment = "😎 Not bad"
            elif 7 < self.score1 <= 9:
                comment = "🔥 Almost perfect"
            elif self.score1 == 10:
                comment = "👑 God tier. No notes."

        if "PvP" in self.mode:
            result = f"Final Scores:\n{self.player1_name}: {self.score1}\n{self.player2_name}: {self.score2}"
        else:
            result = f"Yoreur sco: {self.score1}/ {len(self.questions)}{comment}"

        score_label = QLabel(result)
        score_label.setAlignment(Qt.AlignCenter)
        score_label.setStyleSheet("font-weight: bold; font-size: 18px;")
        layout.addWidget(score_label)

        if "PvP" not in self.mode:
            img = QLabel()
            pic = QPixmap(self.get_score_image(self.score1))
            if not pic.isNull():
                img.setPixmap(pic.scaledToWidth(200))
                img.setAlignment(Qt.AlignCenter)
                layout.addWidget(img)

        if "PvP" not in self.mode:
            grid_widget = QWidget()
            grid_layout = QGridLayout()
            grid_widget.setLayout(grid_layout)

            for idx, item in enumerate(self.answer_summary):
                a = item['your_answer']
                c = item['correct_answer']
                correct = item['is_correct']

                icon = "✅" if correct else "❌"
                color = "#c8e6c9" if correct else "#ffcdd2"

                label = QLabel(
                    f"<b>{icon} Q{idx+1}</b><br>"
                    f"<b>You:</b> {a}<br>"
                    f"<b>Correct:</b> {c}"
                )
                label.setStyleSheet(f"background-color: {color}; padding: 10px; border-radius: 8px;")
                label.setWordWrap(True)

                # Row = idx % 5 (0-4), Column = 0 (left) or 1 (right)
                row = idx % 5
                col = 0 if idx < 5 else 1
                grid_layout.addWidget(label, row, col)

        layout.addWidget(grid_widget)

        if "PvP" in self.mode:
            winner = (
                "It's a tie!" if self.score1 == self.score2 else
                f"{self.player1_name if self.score1 > self.score2 else self.player2_name} wins! 🏆"
            )

            winner_label = QLabel(winner)
            winner_label.setAlignment(Qt.AlignCenter)
            winner_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #333;")
            layout.addWidget(winner_label)

        buttons = QDialogButtonBox(QDialogButtonBox.Retry | QDialogButtonBox.Close)
        layout.addWidget(buttons)

        buttons.accepted.connect(lambda: [
        dialog.accept(),
        self.clear_layout(),
        self.init_intro()
        ])
        buttons.rejected.connect(lambda: sys.exit())

        dialog.setLayout(layout)
        dialog.exec_()

    def show_sudden_death_score(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Game Over ☠️")
        dialog.resize(500, 400)
        layout = QVBoxLayout()

        # Score and comment
        total_qs = sum(len(qset) for qset in self.all_questions.values())
        score = self.score1

        # 🔥 Pick comment based on performance
        if score <= 30:
            comment = "You had 3 lives 🤡"
            img_file = "verybad.jpg"
        elif score <= 70:
            comment = "😬 Not your day"
            img_file = "okay.jpg"
        elif score <= 120:
            comment = "🧠 Respectable grind!"
            img_file = "nice.jpeg"
        elif score <= 179:
            comment = "🔥 DAMN"
            img_file = "whimsical.jpg"
        else:
            comment = "👑 GOAT. Simply built different"
            img_file = "GOAT.jpg"

        # Display score and comment
        label = QLabel(f"You survived {score} out of {total_qs} questions!\n\n{comment}")
        label.setAlignment(Qt.AlignCenter)
        label.setStyleSheet("font-size: 18px; font-weight: bold;")
        layout.addWidget(label)

    # Image
        img = QPixmap(img_file)
        img_label = QLabel()
        img_label.setPixmap(img.scaledToWidth(200))
        img_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(img_label)

        # Buttons
        buttons = QDialogButtonBox(QDialogButtonBox.Retry | QDialogButtonBox.Close)
        buttons.accepted.connect(lambda: [dialog.accept(), self.clear_layout(), self.init_intro(), self.show()])
        buttons.rejected.connect(lambda: sys.exit())
        layout.addWidget(buttons)

        dialog.setLayout(layout)
        dialog.exec_()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    quiz = QuizApp()
    quiz.show()
    sys.exit(app.exec_())
